import os

os.system("pip install pyserial")
os.system("pip install pillow")