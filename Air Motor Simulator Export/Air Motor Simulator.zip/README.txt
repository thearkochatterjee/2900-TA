Air Motor Simulator README
On first time running the program. Run the installation script.
Then run the "Air Motor.py" python file